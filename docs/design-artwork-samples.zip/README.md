# Keypad Graphics samples for the Button Designer

Real button artwork from the OMNI keypad's Keypad Graphics. Use these images in
place of the prototype's CSS stand-ins for shapes and ready-made buttons.

Every image is 188 x 188 px, the size of an 8-button keypad's button.

## ready-made/

Finished buttons, with the icon and label built in. Each has an _OFF image
(grey) and an _ON image (bright red). These are 8 of the 19 ready-made buttons;
the others are Dante, None, Player, Player_Controls, SigGen, Slot1/2/3_Play and
Slot1/2/3_Stop.

In the Library tab, a ready-made tile shows the _OFF image, with the file stem
below it (for example AudioMute_Squared).

## shapes/

The background artwork for Shape layers, in three sets. All three are square
buttons. Bubble isn't a pill, and Circle 45 isn't a circle: Bubble has a gloss
highlight across the top, and Circle 45 has large rounded corners.

Colours with an OFF and ON pair (a dimmer OFF, a brighter ON). These samples
have Red, Blue, Green and Orange:

- Squared and Bubble: Aqua, Blue, Green, Magenta, Orange, Purple, Red, Yellow.
- Circle 45: Aqua, Blue, Green, Magenta, Orange, Purple, Red, Yellow.

Colours with one image, used for both OFF and ON:

- Squared and Bubble: Black, Grey, White.
- Circle 45: Black, DkGrey, LtGrey, White.

The grey image is included for each set (Squared_Grey, Bubble_Grey,
Circle45_DkGrey). The designer's custom colour (the "+" swatch) recolours the
set's grey artwork to any OFF and ON colour, keeping its shading.

On the keypad, a Shape layer sits at the bottom, with Icon and Text layers on
top. The swatches in the Shape settings show each colour's OFF and ON artwork
side by side.
